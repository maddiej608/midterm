const prevButton = document.getElementById("prevButton");
const nextButton = document.getElementById("nextButton");
nextButton.addEventListener('click', function () 
                       prevButton.addEventListener('click', function () 
