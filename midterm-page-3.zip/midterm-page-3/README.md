# Midterm page 3

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maddie-Jensen/pen/bGJgBBK](https://codepen.io/Maddie-Jensen/pen/bGJgBBK).

